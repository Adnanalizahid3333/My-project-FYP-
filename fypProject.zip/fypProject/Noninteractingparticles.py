import numpy as np
import py3Dmol


def get_initial_velocities():
    x_vel = [2 * (np.random.random() - 0.5) * box_width for i in range(n_particles)]
    y_vel = [2 * (np.random.random() - 0.5) * box_width for i in range(n_particles)]

    return x_vel, y_vel


def get_initial_coordinates():
    x_coord = [np.random.random() * box_width for i in range(n_particles)]
    y_coord = [np.random.random() * box_width for i in range(n_particles)]

    return x_coord, y_coord


def add_frame(xs, ys, i):
    global trajectory
    if i == 0:
     trajectory = ''
    trajectory += str(n_particles) + '\ntitle\n'
    for x, y in zip(xs, ys):
     trajectory += ' '.join(['Ar', str(x), str(y), '0.0\n'])


def take_step(x_coord, y_coord, x_vel, y_vel):
    for i in range(n_particles):
        x_coord[i] += x_vel[i]*dt
        y_coord[i] += y_vel[i]*dt

        if abs(x_coord[i])>box_width:
          x_vel[i] = -x_vel[i]
          x_coord[i] += x_vel[i]*dt

        if abs(y_coord[i])>box_width:
            y_vel[i] = -y_vel[i]
            y_coord[i] += y_vel[i]*dt

    return x_coord, y_coord, x_vel, y_vel


n_particles = 10
box_width = 10
n_steps = 5000
dt = 0.001
global trajectory

x_coord, y_coord = get_initial_coordinates()

x_vel, y_vel = get_initial_velocities()

for i in range(n_steps):
    x_coord, y_coord, x_vel, y_vel = take_step(x_coord, y_coord, x_vel, y_vel)

    if i % 10 == 0:
     add_frame(x_coord, y_coord, i)

view = py3Dmol.view()
view.addModelsAsFrames(trajectory, 'xyz')
view.animate({'loop': 'forward', 'reps': 1})
view.setStyle({'sphere': {'radius': 0.5}})
view.zoomTo()