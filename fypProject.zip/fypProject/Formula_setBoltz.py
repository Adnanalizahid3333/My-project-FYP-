import time
import matplotlib.pyplot as plt
import numpy as np
from LJ import LJ
from MorseP import MorseP

# maxwell boltzmann probability density function in 2 dimensions

def maxwellboltzmann(v, m, k, T):
    return ((m * v) / (k * T)) * np.exp((-m * v ** 2)/(2 * k * T))


if __name__ == "__main__":
    perft()
