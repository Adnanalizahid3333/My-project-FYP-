# import LJ_Potential
# import  Morse_Potential
if __name__ == "__main__":
    imp = __import__("LJ_Potential")
    imp2 = __import__("Morse_Potential")
