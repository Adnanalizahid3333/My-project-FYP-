import numpy as np
from LJ import LJ
import pygame
import pygame_gui as set_gui

pygame.init()
md = LJ()

md.load_settings("Set_Varibles.yaml")
md.debugging = True
RectangularArea = 600

pxPerU = int(round(RectangularArea / md.config["boxLength"]))
RAD = int(round(pxPerU / 2))
MAGFACTOR = 2
interface = pygame.display.set_mode((1200, RectangularArea))
pygame.display.set_caption("Molecular Dynamics Simulation For N Particles (LJ)")
manager = set_gui.UIManager((1200, RectangularArea), theme_path="LJ_Theme.json")
timer = pygame.time.Clock()

StartBtn = set_gui.elements.UIButton(relative_rect=pygame.Rect((840, 10), (170, 50)),
                                     text='Run',
                                     manager=manager)
StepBtn = set_gui.elements.UIButton(relative_rect=pygame.Rect((1020, 10), (170, 50)),
                                    text="Next Position",
                                    manager=manager)

DataBlock = set_gui.elements.ui_label.UILabel(relative_rect=pygame.Rect((840, 130), (350, 40)),
                                              text="FPS: 0.0    Time: 0.0    Iterations: 0.0",
                                              manager=manager)
reset = set_gui.elements.UIButton(relative_rect=pygame.Rect((840, 80), (350, 40)),
                                  text="Re_Adjust",
                                  manager=manager)
energy = set_gui.elements.ui_label.UILabel(relative_rect=pygame.Rect((840, 180), (350, 50)), manager=manager,
                                           text=" Energy: 0.0")
avgt = set_gui.elements.ui_label.UILabel(relative_rect=pygame.Rect((840, 240), (350, 50)), manager=manager,
                                         text=" Average T: 0.0")
instantt = set_gui.elements.ui_label.UILabel(relative_rect=pygame.Rect((840, 300), (350, 40)), manager=manager,
                                             text=" Instant T: 0.0")
avgp = set_gui.elements.ui_label.UILabel(relative_rect=pygame.Rect((840, 350), (350, 50)), manager=manager,
                                         text=" Average P: 0.0")
instantp = set_gui.elements.ui_label.UILabel(relative_rect=pygame.Rect((840, 410), (350, 50)), manager=manager,
                                             text=" Instant P: 0.0")
Normal_Velocity = set_gui.elements.ui_label.UILabel(relative_rect=pygame.Rect((840, 470), (350, 50)), manager=manager,
                                                    text=" Normalized Velocity: 0.0")
Normal_Acceleration = set_gui.elements.ui_label.UILabel(relative_rect=pygame.Rect((840, 530), (350, 50)),
                                                        manager=manager, text=" Normalized Acceleration: 0.0")

MainPanel = pygame.Surface((400, 800))
# setting flags
simulating = False
running = True
# N = config["No_of_Particles"]
# print(N)
print("time  iterations  E  avgT  instantT  avgP   instantP\n")
while running:
    time_delta = timer.tick(60) / 1000.0
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

        if event.type == pygame.USEREVENT:
            if event.user_type == set_gui.UI_BUTTON_PRESSED:
                if event.ui_element == StartBtn:
                    if (simulating):
                        StartBtn.set_text("Resume")
                    else:
                        StartBtn.set_text("Pause")
                    simulating = not simulating

                elif event.ui_element == StepBtn:
                    md.step_forward()

                elif event.ui_element == reset:
                    if not simulating:
                        md.reset()

        manager.process_events(event)

    interface.fill((37, 59, 59 ))  # background main panel left side
    MainPanel.fill((255, 54, 0))  # background main panel right side
    factvel = np.linalg.norm(md.vel)
    factacc = np.linalg.norm(md.acc)
    norm_vel = (md.vel / factvel)
    pp = 5
    for i in range(md.config["No_of_Particles"]):
        Post_x = int(round(md.pos[i][0] * pxPerU))
        Post_y = int(round(RectangularArea - md.pos[i][1] * pxPerU))
        # reverse y-direction of the arrow
        Vel_x = int(round(Post_x + norm_vel[i][0] * MAGFACTOR * pxPerU))
        Vel_y = int(round(Post_y + norm_vel[i][1] * MAGFACTOR * pxPerU * -1))
        # drawing atoms /particles for water and oil interaction

        pygame.draw.circle(interface, (249, 147, 0 ), (Post_x, Post_y), RAD)
        # drawing direction on atom
        pygame.draw.line(interface, (255, 255, 255  ), (Post_x, Post_y), (Vel_x, Vel_y), 3)

    if simulating:
        for i in range(5):
            md.step_forward()
    DataBlock.set_text(f"FPS: {timer.get_fps():.1f}   Time: {md.time:.2f}  Iterations: {md.iterations}")
    energy.set_text(f"Energy: {md.energy:.3f}")
    avgt.set_text(f"Average T: {md.avgT:.3f}")
    instantt.set_text(f"Instant T: {md.instantT:.3f}")
    avgp.set_text(f"Average P: {md.avgP:.3f}")
    instantp.set_text(f"Instant P: {md.instantP:.3f}")
    Normal_Velocity.set_text(f"Normalized Velocity: {factvel:.2f}")
    Normal_Acceleration.set_text(f"Normalized Acceleration: {factacc:.2f}")

    interface.blit(MainPanel, (800, 0))  # panel parameter background
    manager.update(time_delta)
    manager.draw_ui(interface)
    pygame.display.flip()

pygame.quit()